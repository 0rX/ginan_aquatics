<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="shortcut icon" href="<?php echo e(url('assets/images/logo/logo.png')); ?>" type="image/x-icon">
    <title><?php echo e($title); ?> | Admin Ginan Aquatics</title>

    <?php echo $__env->make('components.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        @media print {
            @page {
                margin: 0;
            }

            body {
                margin: 1.6cm;
            }
        }

        tr {
            font-size: 12px !important;
        }

        tr th {
            font-size: 10px !important;
        }
    </style>
</head>

<body>

    <div class="container-fluid py-5">
        <h4 class="text-center fw-semibold mb-5"><?php echo e($title); ?></h4>
        <?php if($items->count() > 0): ?>
            <table class="table table-bordered">
                <thead class="fw-semibold text-uppercase fs-7">
                    <tr>
                        <th>tanggal pemesanan</th>
                        <th>kode pemesanan</th>
                        <th>nama pemesan</th>
                        <th>alamat pengiriman</th>
                        <th>total harga</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="vertical-align: middle">
                            <td><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d F Y')); ?>

                            </td>
                            <td>#PESANAN000<?php echo e($item->id); ?></td>
                            <td><?php echo e($item->customer->name); ?></td>
                            <td><?php echo e($item->shipping_address); ?></td>
                            <td>Rp. <?php echo e(number_format($item->total_amount)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="4" class="fw-semibold">Total</td>
                        <td class="fw-semibold fs-7">Rp. <?php echo e(number_format($items->sum('total_amount'))); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
        <?php else: ?>
            <p class="mb-0 text-danger text-center">Belum ada transaksi</p>
        <?php endif; ?>
    </div>

    <script>
        window.print()
    </script>
</body>

</html>
<?php /**PATH D:\FREELANCE\Projects\2023\07 JULI\Ginan\ginan-marketplace\resources\views/pages/admin/transactions/print.blade.php ENDPATH**/ ?>