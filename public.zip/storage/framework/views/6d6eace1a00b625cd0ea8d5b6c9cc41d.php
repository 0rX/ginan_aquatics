<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="shortcut icon" href="<?php echo e(url('assets/images/logo/logo.png')); ?>" type="image/x-icon">
    <title><?php echo e($title); ?> - Ginan Marketplace</title>

    <?php echo $__env->make('components.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="bg-body-tertiary py-3">
    <div class="container">
        <div class="row align-items-center justify-content-center min-vh-100">
            <div class="col-md-5">
                <a href="<?php echo e(route('home')); ?>">
                    <img src="<?php echo e(url('assets/images/logo/logo.png')); ?>" alt="Arunika" style="width: 90px"
                        class="d-block mx-auto mb-5">
                </a>

                <div class="card bg-white border-0">
                    <div class="card-body p-4">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('components.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\ginan-marketplace\resources\views/layouts/auth.blade.php ENDPATH**/ ?>