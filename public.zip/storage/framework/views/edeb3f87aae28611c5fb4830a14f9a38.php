<?php $__env->startSection('content'); ?>
    <section class="checkout" id="collection">
        <div class="container">
            <h2 class="section-title mb-5">Pesanan Saya</h2>

            <div class="table-responsive">
                <table class="table">
                    <thead class="fw-semibold text-uppercase fs-7">
                        <tr>
                            <th>Tanggal</th>
                            <th>kode pemesanan</th>
                            <th>produk</th>
                            <th>data pemesan</th>
                            <th>total harga</th>
                            <th>status</th>
                            <th>aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="vertical-align: middle">
                                <td>
                                    <?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d F Y')); ?>

                                </td>
                                <td>#PESANAN000<?php echo e($item->id); ?></td>
                                <td>
                                    <div class="d-flex">
                                        <button class="btn btn-light d-flex align-items-center gap-2" type="button"
                                            data-bs-toggle="modal" data-bs-target="#detailModal<?php echo e($item->id); ?>">
                                            <i class="bx bx-file"></i> Lihat Produk
                                        </button>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex">
                                        <button class="btn btn-light d-flex align-items-center gap-2" type="button"
                                            data-bs-toggle="modal" data-bs-target="#detailPemesan<?php echo e($item->id); ?>">
                                            <i class="bx bx-file"></i> Lihat Pemesan
                                        </button>
                                    </div>
                                </td>
                                <td>Rp. <?php echo e(number_format($item->total_amount)); ?></td>
                                <td>
                                    <?php if($item->status == 'in_progress'): ?>
                                        <span class="badge bg-warning py-2 d-flex align-items-center gap-2"
                                            style="width: max-content">
                                            <i class='bx bx-package'></i> Proses
                                        </span>
                                    <?php elseif($item->status == 'on_delivery'): ?>
                                        <span class="badge bg-info py-2 d-flex align-items-center gap-2"
                                            style="width: max-content">
                                            <i class='bx bx-car'></i> Dikirim
                                        </span>
                                    <?php elseif($item->status == 'success'): ?>
                                        <span class="badge bg-success py-2 d-flex align-items-center gap-2"
                                            style="width: max-content">
                                            <i class='bx bx-check'></i> Sukses / Diterima
                                        </span>
                                    <?php elseif($item->status == 'cancelled'): ?>
                                        <span class="badge bg-danger py-2 d-flex align-items-center gap-2"
                                            style="width: max-content">
                                            <i class='bx bx-error-circle'></i> Dibatalkan
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div>
                                        <?php if($item->status == 'on_delivery'): ?>
                                            <form action="<?php echo e(route('home.my-orders.update', $item->id)); ?>" method="post"
                                                class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <input type="hidden" name="status" value="success">
                                                <button class="btn btn-primary btn-sm w-100 mb-1" type="submit">Terima
                                                    Pesanan</button>
                                            </form>
                                        <?php endif; ?>
                                        <a href="https://wa.me/6285600071007"
                                            class="btn btn-success btn-sm px-3 d-flex align-items-center gap-2">
                                            <i class="bx bxl-whatsapp"></i> Hubungi Admin
                                        </a>
                                    </div>
                                </td>
                            </tr>

                            <div class="modal fade" id="detailModal<?php echo e($item->id); ?>" tabindex="-1"
                                aria-labelledby="detailModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="detailModalLabel">Detail Produk</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <?php $__currentLoopData = $item->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="row mb-1">
                                                    <div class="col-5">Produk</div>
                                                    <div class="col-7 fw-semibold">: <?php echo e($detail->product->name); ?></div>
                                                </div>
                                                <div class="row mb-1">
                                                    <div class="col-5">Quantity</div>
                                                    <div class="col-7 fw-semibold">: <?php echo e(number_format($detail->quantity)); ?>

                                                    </div>
                                                </div>
                                                <div class="row mb-1">
                                                    <div class="col-5">Harga</div>
                                                    <div class="col-7 fw-semibold">: Rp.
                                                        <?php echo e(number_format($detail->price)); ?>

                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <div class="col-5">Sub Total</div>
                                                    <div class="col-7 fw-semibold">: Rp.
                                                        <?php echo e(number_format($detail->price * $detail->quantity)); ?>

                                                    </div>
                                                </div>

                                                <hr class="mb-3">
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" id="detailPemesan<?php echo e($item->id); ?>" tabindex="-1"
                                aria-labelledby="detailPemesanLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="detailPemesanLabel">
                                                Detail Pemesan
                                            </h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="row mb-1">
                                                <div class="col-5">Nama Pemesan</div>
                                                <div class="col-7 fw-semibold">:
                                                    <?php echo e($item->customer->name); ?></div>
                                            </div>
                                            <div class="row mb-1">
                                                <div class="col-5">Alamat</div>
                                                <div class="col-7 fw-semibold">:
                                                    <?php echo e($item->shipping_address); ?></div>
                                            </div>
                                            <div class="row mb-1">
                                                <div class="col-5">Nomor Telepon</div>
                                                <div class="col-7 fw-semibold">:
                                                    <?php echo e($item->customer->phone_number); ?></div>
                                            </div>
                                            <div class="row mb-1">
                                                <div class="col-5">Alamat Email</div>
                                                <div class="col-7 fw-semibold">:
                                                    <?php echo e($item->customer->email); ?></div>
                                            </div>
                                            <div class="row mb-1">
                                                <div class="col-5">Transfer Pembayaran</div>
                                                <div class="col-7 fw-semibold">:
                                                    <?php echo e($item->bank_name); ?></div>
                                            </div>
                                            <div class="row mb-1">
                                                <div class="col-5">Bukti Pembayaran</div>
                                                <div class="col-7 fw-semibold">:
                                                    <img src="<?php echo e(url('storage/' . $item->proof_of_payment)); ?>"
                                                        class="w-50" alt="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ginan-marketplace\resources\views/pages/home/orders/my-orders.blade.php ENDPATH**/ ?>