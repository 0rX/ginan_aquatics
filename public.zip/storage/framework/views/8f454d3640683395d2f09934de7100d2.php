<?php $__env->startSection('content'); ?>
    <section class="py-5">
        <div class="container">
            <div class="d-flex align-items-center justify-content-between mb-5">
                <div class="d-flex align-items-center gap-2">
                    <h4 class="text-dark fw-semibold mb-0">
                        Laporan Penjualan Bulan <?php echo e($month); ?> Tahun <?php echo e($year); ?>

                    </h4>
                    <a href="<?php echo e(route('admin.report.print', ['bulan' => $month, 'tahun' => $year])); ?>"
                        class="btn btn-success d-flex align-items-center gap-2" target="_blank">
                        <i class="bx bx-printer"></i> Cetak Laporan
                    </a>
                </div>
                <a href="<?php echo e(route('admin.report')); ?>" class="btn btn-light d-flex align-items-center gap-2">
                    <i class="bx bx-arrow-left"></i> Kembali
                </a>
            </div>

            <div class="card border-0">
                <div class="card-body">
                    <?php if($items->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead class="fw-semibold text-uppercase fs-7">
                                    <tr>
                                        <th>tanggal pemesanan</th>
                                        <th>kode pemesanan</th>
                                        <th>produk</th>
                                        <th>data pemesan</th>
                                        <th>total harga</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr style="vertical-align: middle">
                                            <td><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d F Y')); ?>

                                            </td>
                                            <td>#PESANAN000<?php echo e($item->id); ?></td>
                                            <td>
                                                <div class="d-flex">
                                                    <button class="btn btn-light d-flex align-items-center gap-2"
                                                        type="button" data-bs-toggle="modal"
                                                        data-bs-target="#detailModal<?php echo e($item->id); ?>">
                                                        <i class="bx bx-file"></i> Lihat Produk
                                                    </button>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="d-flex">
                                                    <button class="btn btn-light d-flex align-items-center gap-2"
                                                        type="button" data-bs-toggle="modal"
                                                        data-bs-target="#detailPemesan<?php echo e($item->id); ?>">
                                                        <i class="bx bx-file"></i> Lihat Pemesan
                                                    </button>
                                                </div>
                                            </td>
                                            <td>Rp. <?php echo e(number_format($item->total_amount)); ?></td>
                                        </tr>

                                        <div class="modal fade" id="detailModal<?php echo e($item->id); ?>" tabindex="-1"
                                            aria-labelledby="detailModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="detailModalLabel">Detail Produk
                                                        </h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <?php $__currentLoopData = $item->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="row mb-1">
                                                                <div class="col-5">Produk</div>
                                                                <div class="col-7 fw-semibold">:
                                                                    <?php echo e($detail->product->name); ?></div>
                                                            </div>
                                                            <div class="row mb-1">
                                                                <div class="col-5">Quantity</div>
                                                                <div class="col-7 fw-semibold">:
                                                                    <?php echo e(number_format($detail->quantity)); ?>

                                                                </div>
                                                            </div>
                                                            <div class="row mb-1">
                                                                <div class="col-5">Harga</div>
                                                                <div class="col-7 fw-semibold">: Rp.
                                                                    <?php echo e(number_format($detail->price)); ?>

                                                                </div>
                                                            </div>
                                                            <div class="row mb-3">
                                                                <div class="col-5">Sub Total</div>
                                                                <div class="col-7 fw-semibold">: Rp.
                                                                    <?php echo e(number_format($detail->price * $detail->quantity)); ?>

                                                                </div>
                                                            </div>

                                                            <hr class="mb-3">
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal fade" id="detailPemesan<?php echo e($item->id); ?>" tabindex="-1"
                                            aria-labelledby="detailPemesanLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="detailPemesanLabel">
                                                            Detail Pemesan
                                                        </h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row mb-1">
                                                            <div class="col-5">Nama Pemesan</div>
                                                            <div class="col-7 fw-semibold">:
                                                                <?php echo e($item->customer->name); ?></div>
                                                        </div>
                                                        <div class="row mb-1">
                                                            <div class="col-5">Alamat</div>
                                                            <div class="col-7 fw-semibold">:
                                                                <?php echo e($item->shipping_address); ?></div>
                                                        </div>
                                                        <div class="row mb-1">
                                                            <div class="col-5">Nomor Telepon</div>
                                                            <div class="col-7 fw-semibold">:
                                                                <?php echo e($item->customer->phone_number); ?></div>
                                                        </div>
                                                        <div class="row mb-1">
                                                            <div class="col-5">Alamat Email</div>
                                                            <div class="col-7 fw-semibold">:
                                                                <?php echo e($item->customer->email); ?></div>
                                                        </div>
                                                        <div class="row mb-1">
                                                            <div class="col-5">Transfer Pembayaran</div>
                                                            <div class="col-7 fw-semibold">:
                                                                <?php echo e($item->bank_name); ?></div>
                                                        </div>
                                                        <div class="row mb-1">
                                                            <div class="col-5">Bukti Pembayaran</div>
                                                            <div class="col-7 fw-semibold">:
                                                                <img src="<?php echo e(url('storage/' . $item->proof_of_payment)); ?>"
                                                                    class="w-50" alt="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td colspan="3" class="fw-semibold">Total</td>
                                        <td class="fw-semibold fs-5">
                                            Rp. <?php echo e(number_format($items->sum('total_amount'))); ?>

                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="mb-0 text-danger text-center">Belum ada transaksi</p>
                    <?php endif; ?>
                </div>
            </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ginan-marketplace\resources\views/pages/admin/transactions/report-filter.blade.php ENDPATH**/ ?>