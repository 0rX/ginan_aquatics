<?php $__env->startSection('content'); ?>
    <section class="py-5">
        <div class="container">
            <div class="d-flex flex-wrap gap-2 align-items-center justify-content-between mb-5">
                <h4 class="text-dark fw-semibold">Edit <?php echo e($item->title); ?></h4>
                <a href="<?php echo e(route('produk.index')); ?>" class="btn btn-light d-flex align-items-center gap-2">
                    <i class="bx bx-arrow-back"></i> Batal & Kembali
                </a>
            </div>

            <div class="card border-0">
                <div class="card-body">
                    <form action="<?php echo e(route('produk.update', $item->id)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="category_id">Pilih Kategori</label>
                                    <select name="category_id" id="category_id" class="form-control">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"
                                                <?php echo e($category->id == $item->category_id ? 'selected' : ''); ?>>
                                                <?php echo e($category->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="mb-3">
                                    <label for="name">Nama Produk</label>
                                    <input type="text" name="name" id="name" class="form-control"
                                        value="<?php echo e($item->name); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="stock">Stok</label>
                                    <input type="number" name="stock" id="stock" class="form-control"
                                        value="<?php echo e($item->stock); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="price">Harga</label>
                                    <input type="number" name="price" id="price" class="form-control"
                                        value="<?php echo e($item->price); ?>" required>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="mb-3">
                                    <label for="image">Gambar</label>
                                    <input type="file" accept="image/*" name="image" id="image"
                                        class="form-control">
                                    <span class="text-secondary fs-7">Pilih gambar jika ingin menggantinya</span>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="mb-3">
                                    <label for="description">Deskripsi</label>
                                    <textarea name="description" id="description" cols="30" rows="10" class="form-control"><?php echo e($item->description); ?></textarea>
                                </div>
                            </div>
                        </div>
                        <button class="btn btn-primary" type="submit">Simpan Perubahan</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-style'); ?>
    <link rel="stylesheet" href="<?php echo e(url('assets/vendors/summernote/summernote.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
    <script src="<?php echo e(url('assets/vendors/summernote/summernote.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#description').summernote({
                height: 200
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ginan-marketplace\resources\views/pages/admin/products/edit.blade.php ENDPATH**/ ?>