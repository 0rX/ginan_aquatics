<?php $__env->startSection('content'); ?>
    <section class="header-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <img src="<?php echo e(url('assets/images/logo/logo.png')); ?>" alt="Ginan Marketplace" class="d-block mx-auto mb-4"
                        style="width: 200px">

                    <h1 class="header-title text-center text-dark fw-bold mb-2">
                        Selamat Datang di Ginan Marketplace
                    </h1>
                    <p class="mb-4 text-secondary text-center">
                        Menyediakan beragam jenis ikan cupang dengan berbagai warna dan jenis yang indah, serta menyediakan
                        perlengkapan dan makanan untuk perawatan ikan cupang.
                    </p>
                    <a href="#collection" class="btn btn-dark px-3 py-2 d-block mx-auto" style="width: max-content">
                        Lihat Koleksi
                    </a>
                </div>
            </div>
        </div>
    </section>

    <section class="collection-section" id="collection">
        <div class="container">
            <div class="d-flex flex-wrap gap-2 align-items-center justify-content-between mb-5">
                <h3 class="section-title mb-0">Koleksi Kami</h3>
                <a href="<?php echo e(route('home.produk')); ?>" class="btn btn-light px-3">Lihat Semua</a>
            </div>

            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <?php echo $__env->make('components.card-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <section class="superiority-section bg-primary">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="mx-auto rounded-circle bg-white d-flex align-items-center justify-content-center mb-3"
                        style="width: 80px; height: 80px">
                        <img src="<?php echo e(url('assets/images/tag.png')); ?>" class="w-50" alt="">
                    </div>

                    <h4 class="text-white text-center">Harga Termurah</h4>
                </div>
                <div class="col-md-4">
                    <div class="mx-auto rounded-circle bg-white d-flex align-items-center justify-content-center mb-3"
                        style="width: 80px; height: 80px">
                        <img src="<?php echo e(url('assets/images/stopwatch.png')); ?>" class="w-50" alt="">
                    </div>

                    <h4 class="text-white text-center">Pengiriman Cepat</h4>
                </div>
                <div class="col-md-4">
                    <div class="mx-auto rounded-circle bg-white d-flex align-items-center justify-content-center mb-3"
                        style="width: 80px; height: 80px">
                        <img src="<?php echo e(url('assets/images/choice.png')); ?>" class="w-50" alt="">
                    </div>

                    <h4 class="text-white text-center">Banyak Pilihan</h4>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-white">
        <div class="container">
            <h3 class="section-title text-center mb-5">Testimoni</h3>

            <div id="testimoniCarousel" class="carousel carousel-dark slide">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="row justify-content-center">
                            <div class="col-md-5">
                                <img src="<?php echo e(url('assets/images/people.jpg')); ?>"
                                    style="width: 65px; height: 65px; object-fit: cover" alt=""
                                    class="rounded-circle mx-auto d-block mb-3">
                                <p class="mb-0 text-center text-dark fw-semibold">Johana Fixedia</p>
                                <p class="mb-3 text-center text-secondary fs-7">Pecinta Ikan</p>
                                <p class="mb-0 text-center text-secondary">
                                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Necessitatibus ducimus neque
                                    fuga recusandae consequuntur molestiae voluptatum, officia non distinctio. Quam delectus
                                    blanditiis praesentium maiores veritatis esse hic quo incidunt qui.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="row justify-content-center">
                            <div class="col-md-5">
                                <img src="<?php echo e(url('assets/images/people.jpg')); ?>"
                                    style="width: 65px; height: 65px; object-fit: cover" alt=""
                                    class="rounded-circle mx-auto d-block mb-3">
                                <p class="mb-0 text-center text-dark fw-semibold">Johana Fixedia</p>
                                <p class="mb-3 text-center text-secondary fs-7">Pecinta Ikan</p>
                                <p class="mb-0 text-center text-secondary">
                                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Necessitatibus ducimus neque
                                    fuga recusandae consequuntur molestiae voluptatum, officia non distinctio. Quam delectus
                                    blanditiis praesentium maiores veritatis esse hic quo incidunt qui.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="row justify-content-center">
                            <div class="col-md-5">
                                <img src="<?php echo e(url('assets/images/people.jpg')); ?>"
                                    style="width: 65px; height: 65px; object-fit: cover" alt=""
                                    class="rounded-circle mx-auto d-block mb-3">
                                <p class="mb-0 text-center text-dark fw-semibold">Johana Fixedia</p>
                                <p class="mb-3 text-center text-secondary fs-7">Pecinta Ikan</p>
                                <p class="mb-0 text-center text-secondary">
                                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Necessitatibus ducimus neque
                                    fuga recusandae consequuntur molestiae voluptatum, officia non distinctio. Quam delectus
                                    blanditiis praesentium maiores veritatis esse hic quo incidunt qui.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#testimoniCarousel"
                    data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#testimoniCarousel"
                    data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FREELANCE\Projects\2023\07 JULI\Ginan\ginan-marketplace\resources\views/pages/home/homepage.blade.php ENDPATH**/ ?>