<?php $__env->startSection('content'); ?>
    <section class="collection-section" id="collection">
        <div class="container">
            <h2 class="section-title mb-5">Semua Kategori</h2>

            <div class="row">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <a href="<?php echo e(route('home.kategori.show', $item->slug)); ?>"
                            class="card bg-white border-light mb-3 shadow-sm">
                            <div class="card-body">
                                <h5 class="text-dark mb-0">
                                    <?php echo e($item->name); ?>

                                </h5>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ginan-marketplace\resources\views/pages/home/categories/index.blade.php ENDPATH**/ ?>