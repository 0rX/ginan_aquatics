<script src="<?php echo e(url('assets/vendors/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/vendors/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/main.js')); ?>"></script>
<?php echo $__env->yieldPushContent('addon-script'); ?>
<?php /**PATH D:\FREELANCE\Projects\2023\07 JULI\Ginan\ginan-marketplace\resources\views/components/scripts.blade.php ENDPATH**/ ?>