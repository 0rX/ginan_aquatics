<?php $__env->startSection('content'); ?>
    <section class="py-5">
        <div class="container">
            <div class="d-flex flex-wrap gap-2 align-items-center justify-content-between mb-5">
                <h4 class="text-dark fw-semibold">List Produk</h4>
                <a href="<?php echo e(route('produk.create')); ?>" class="btn btn-primary d-flex align-items-center gap-2">
                    <i class="bx bx-plus"></i> Tambah Produk
                </a>
            </div>

            <div class="card border-0">
                <div class="card-body">
                    <?php if($items->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th class="fs-7 text-uppercase">#</th>
                                        <th class="fs-7 text-uppercase">kategori</th>
                                        <th class="fs-7 text-uppercase">nama produk</th>
                                        <th class="fs-7 text-uppercase">stok</th>
                                        <th class="fs-7 text-uppercase">harga</th>
                                        <th class="fs-7 text-uppercase"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr style="vertical-align: middle">
                                            <td><?php echo e(++$key); ?></td>
                                            <td><?php echo e($item->category->name); ?></td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e(number_format($item->stock)); ?></td>
                                            <td>Rp. <?php echo e(number_format($item->price)); ?></td>
                                            <td>
                                                <div class="d-flex align-items-center justify-content-end gap-2">
                                                    <a href="<?php echo e(route('produk.edit', $item->id)); ?>"
                                                        class="btn btn-sm btn-warning text-white d-flex align-items-center gap-2">
                                                        <i class='bx bx-edit'></i> Edit
                                                    </a>
                                                    <form action="<?php echo e(route('produk.destroy', $item->id)); ?>" method="post"
                                                        class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit"
                                                            class="btn btn-danger btn-sm d-flex align-items-center gap-2"
                                                            onclick="return confirm('Kamu yakin ingin menghapus data ini? Data yang berhubungan juga akan terhapus')">
                                                            <i class="bx bx-trash-alt"></i> Hapus
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="mb-0 text-danger text-center">Belum ada produk</p>
                    <?php endif; ?>
                </div>
            </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ginan-marketplace\resources\views/pages/admin/products/index.blade.php ENDPATH**/ ?>