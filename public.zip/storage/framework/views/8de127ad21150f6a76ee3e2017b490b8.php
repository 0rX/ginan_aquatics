<?php $__env->startSection('content'); ?>
    <section class="checkout" id="checkout">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="card border-0">
                        <div class="card-body">
                            <div class="mb-5 text-center">
                                <i class='bx bx-check-circle text-success' style="font-size: 50px"></i>
                                <h4 class="text-dark fw-semibold mt-2">Terima kasih atas pesanan Anda</h4>
                                <p class="text-secondary mb-5">Pesanan Anda akan segera kami proses.</p>
                            </div>

                            <div class="mb-3">
                                <p class="mb-1 text-dark fw-semibold">Tanggal Transaksi</p>
                                <p class="mb-0 text-secondary"><?php echo e($item->created_at->format('l, d F Y, h:i:s')); ?></p>
                            </div>

                            <div class="mb-3">
                                <p class="mb-1 text-dark fw-semibold">Metode Transfer</p>
                                <p class="mb-0 text-secondary">Transfer via <?php echo e($item->bank_name); ?></p>
                            </div>

                            <div class="mb-3">
                                <p class="mb-1 text-dark fw-semibold">Pesanan Anda</p>
                                <?php $__currentLoopData = $item->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row mb-2">
                                        <div class="col-2">
                                            <img src="<?php echo e(url('storage/' . $detail->product->image)); ?>"
                                                style="width: 100%; height: 100%; object-fit: cover" class="rounded"
                                                alt="<?php echo e($detail->product->name); ?>">
                                        </div>
                                        <div class="col-7">
                                            <?php echo e($detail->product->name); ?>

                                            <br> <span class="fs-7 text-secondary">x<?php echo e($detail->quantity); ?></span>
                                        </div>
                                        <div class="col-3 fw-semibold text-end">Rp. <?php echo e(number_format($detail->price)); ?>

                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <hr class="mb-3" style="border-style: dashed">

                            <div class="mb-4 d-flex align-items-center justify-content-between">
                                <p class="mb-0 text-dark">Grand Total</p>
                                <p class="mb-0 text-dark fs-5 fw-semibold">Rp. <?php echo e(number_format($item->total_amount)); ?></p>
                            </div>

                            <a class="py-2 w-100 btn btn-primary" href="<?php echo e(route('home.produk')); ?>">Lanjutkan Berbelanja</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FREELANCE\Projects\2023\07 JULI\Ginan\ginan-marketplace\resources\views/pages/home/orders/success.blade.php ENDPATH**/ ?>