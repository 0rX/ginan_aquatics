<div class="card mb-3 border-0">
    <a href="<?php echo e(route('home.produk.detail', $item->slug)); ?>">
        <img src="<?php echo e(url('storage/' . $item->image)); ?>" alt="" class="card-img-top">
    </a>
    <div class="card-body p-3">
        <h5 class="text-dark mb-0"><?php echo e($item->name); ?></h5>
        <p class="text-dark mb-0">Rp. <?php echo e(number_format($item->price)); ?></p>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\ginan-marketplace\resources\views/components/card-product.blade.php ENDPATH**/ ?>