<?php $__env->startSection('content'); ?>
    <section class="collection-section" id="collection">
        <div class="container">
            <h2 class="section-title mb-5">Keranjang</h2>

            <div class="table-responsive mb-5">
                <table class="table">
                    <thead>
                        <tr>
                            <th class="text-uppercase fs-7">#</th>
                            <th class="text-uppercase fs-7">nama produk</th>
                            <th class="text-uppercase fs-7">harga</th>
                            <th class="text-uppercase fs-7">quantity</th>
                            <th class="text-uppercase fs-7">sub-total</th>
                            <th class="text-uppercase fs-7"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($item != null): ?>
                            <?php $__currentLoopData = $item->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" id="stock<?php echo e($cart->id); ?>" value="<?php echo e($cart->product->stock); ?>">
                                <tr style="vertical-align: middle">
                                    <td>
                                        <img src="<?php echo e(url('storage/' . $cart->product->image)); ?>"
                                            alt="<?php echo e($cart->product->name); ?>"
                                            style="width: 40px; height: 30px; object-fit: cover" class="rounded">
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('home.produk.detail', $cart->product->slug)); ?>"
                                            class="text-dark text-decoration-underline">
                                            <?php echo e($cart->product->name); ?>

                                        </a>
                                    </td>
                                    <td>Rp. <?php echo e(number_format($cart->price)); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('home.keranjang.update', $cart->id)); ?>" method="post"
                                            class="d-flex flex-column flex-md-row align-items-center gap-2">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <input type="number" name="quantity" id="quantity<?php echo e($cart->id); ?>"
                                                class="form-control w-25" value="<?php echo e($cart->quantity); ?>"
                                                onchange="checkInput(<?php echo e($cart->id); ?>)">
                                            <button type="submit" class="btn btn-secondary btn-sm"
                                                id="btnUpdate<?php echo e($cart->id); ?>">Update</button>
                                        </form>
                                        <span class="text-danger fs-7" id="errorText<?php echo e($cart->id); ?>"></span>
                                    </td>
                                    <td>Rp. <?php echo e(number_format($cart->price * $cart->quantity)); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('home.keranjang.destroy', $cart->id)); ?>" method="post"
                                            class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit"
                                                class="btn btn-danger btn-sm d-flex align-items-center justify-content-center gap-2"
                                                onclick="return confirm('Are you sure to deleted this?')">
                                                <i class="bx bx-trash-alt"></i> Hapus
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="4">Total</td>
                                <th class="fs-5">Rp. <?php echo e(number_format($item->total_amount)); ?></th>
                                <td>&nbsp;</td>
                            </tr>
                        <?php else: ?>
                            <tr>
                                <td colspan="6">
                                    <p class="mb-0 text-center text-danger">Belum Ada Pesanan</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($item != null): ?>
                <div class="row justify-content-end">
                    <div class="col-md-3">
                        <a href="<?php echo e(route('home.checkout.index')); ?>" class="btn btn-primary py-3 px-5 fw-semibold w-100">
                            Checkout Sekarang
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <a href="<?php echo e(route('home.produk')); ?>" class="btn btn-light d-block mx-auto w-50 mt-5">Lanjutkan Berbelanja</a>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-style'); ?>
    <style>
        @media screen and (max-width: 768px) {
            .w-25 {
                width: 100% !important;
            }
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
    <script>
        function checkInput(number) {
            var inputNumber = parseInt(document.getElementById("quantity" + number).value);
            var btnUpdate = document.getElementById("btnUpdate" + number);
            var errorText = document.getElementById("errorText" + number);

            if (inputNumber > parseInt(document.getElementById("stock" + number).value)) {
                btnUpdate.disabled = true;
                errorText.textContent = "Input melebihi stok!";
            } else {
                btnUpdate.disabled = false;
                errorText.textContent = "";
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ginan-marketplace\resources\views/pages/home/orders/cart.blade.php ENDPATH**/ ?>