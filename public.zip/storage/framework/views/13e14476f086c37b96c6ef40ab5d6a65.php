<link rel="stylesheet" href="<?php echo e(url('assets/vendors/bootstrap/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/vendors/boxicons/css/boxicons.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>">
<?php echo $__env->yieldPushContent('addon-style'); ?>
<?php /**PATH D:\FREELANCE\Projects\2023\07 JULI\Ginan\ginan-marketplace\resources\views/components/styles.blade.php ENDPATH**/ ?>