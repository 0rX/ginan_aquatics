<script src="{{ url('assets/vendors/jquery/jquery.min.js') }}"></script>
<script src="{{ url('assets/vendors/bootstrap/bootstrap.bundle.min.js') }}"></script>
<script src="{{ url('assets/js/main.js') }}"></script>
@stack('addon-script')
