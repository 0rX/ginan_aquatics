<link rel="stylesheet" href="{{ url('assets/vendors/bootstrap/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ url('assets/vendors/boxicons/css/boxicons.min.css') }}">
<link rel="stylesheet" href="{{ url('assets/css/style.css') }}">
@stack('addon-style')
